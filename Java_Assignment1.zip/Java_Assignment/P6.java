import java.util.Scanner;
class P6{
public static void main(String args[]){
int num1,num2,ans1,ans2,ans3,ans4,ans5;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the two nos");
num1=sc.nextInt();
num2=sc.nextInt();

ans1=num1+num2;
ans2=num1-num2;
ans3=num1*num2;
ans4=num1/num2;
ans5=num1%num2;

System.out.println("Addition:"+ ans1);
System.out.println("Substraction:"+ ans2);
System.out.println("Multiplication:"+ ans3);
System.out.println("Division:"+ ans4);
System.out.println("Modulus:"+ ans5);

}
}
