class P13{
public static void main(String args[]){

int a=10,b=20,c=30;
int large=c>(a>b ? a:b) ? c:(a>b ? a:b);
System.out.println("Greatest number "+ large);

}
}	