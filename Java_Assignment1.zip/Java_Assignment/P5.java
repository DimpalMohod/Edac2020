import java.util.Scanner;
class P5{
public static void main(String args[]){

int fno,sno,op;
Scanner sc = new Scanner(System.in);
System.out.println("Enter numbers");

fno=sc.nextInt();
sno=sc.nextInt();
op=fno*sno;

System.out.println("The product of two numbers "+ op);

}
}
