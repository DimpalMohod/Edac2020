import java.util.Scanner;
class P10{
public static void main(String args[]){

System.out.println("Enter temperature in fahrenheit ");
Scanner sc=new Scanner(System.in);

float fah=sc.nextFloat();
//int cel=(int)(5*(fah-32)/9);
float cel=(5*(fah-32)/9);
System.out.println("Temperature in celsius :" + cel);

}
}
