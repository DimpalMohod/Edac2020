import java.util.Scanner;
class P15{
public static void main(String args[]){

System.out.println("Enter your Gender and Age");

Scanner sc = new Scanner(System.in);

char gender = sc.next().charAt(0);

int age = sc.nextInt();

if(age>=25)
	{
		System.out.println("Eligible for marriage");
	}
	

	else
	{
		System.out.println("Not eligible for marriage");
	}

}
}