//2.Write a program to reverse a given number.

import java.util.Scanner;
class P2{
public static void main(String args[]){

System.out.println("Enter number");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int rnum=0;

while(n!=0)
{
	rnum=rnum*10;
	rnum=rnum+n%10;
	n=n/10;
}
System.out.println(rnum);

}
}