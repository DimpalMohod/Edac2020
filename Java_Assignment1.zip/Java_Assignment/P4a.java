/*import java.util.Scanner;
class P4a{
public static void main(String args[]){
int a,b,c,d;
Scanner sc =new Scanner(System.in);
System.out.println("Enter three nos:");
a=sc.nextInt();
b=sc.nextInt();
c=sc.nextInt();
d=-a+b*c;
System.out.println("The output is:"+d);//53
}
}
*/

class P4{
public static void main(String args[]){
int a,b,c,d;
d=-5+8*6;
System.out.println("The output is:"+d);//43
}
}




