class P4b{
public static void main(String args[]){
int num1=55,num2=9,num3=9,ans;
ans=(num1+num2)%num3;
System.out.println("The output is:"+ans);
}
}
