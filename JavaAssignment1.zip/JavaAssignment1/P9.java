import java.util.Scanner;
class P9{
public static void main(String args[]){

int m,yr,week,day;
Scanner sc=new Scanner(System.in);

System.out.println("Enter days");
m=sc.nextInt();
yr=m/365;
m=m%365;

System.out.println("Years "+ yr);
week=m/7;
m=m%7;
System.out.println("Week "+ week);
day=m;
System.out.println("Days "+ day);

}
}