class P4c{
public static void main(String args[]){
int a=20,b=3,c=5,d=8,op;
op=a+-b*c/d;
System.out.println(op);
}
}
