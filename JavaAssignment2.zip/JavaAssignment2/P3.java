//prime or not
import java.util.Scanner;
class P3{
public static void main(String args[]){

System.out.println("Enter number");
Scanner sc=new Scanner(System.in);
int num=sc.nextInt();
boolean flag=false;
for(int i=2;i<=num/2;i++)
{
	if(num%2==0)
	{
 		flag=true;	
		break;
	}
}
if(!flag)
{
System.out.println(num + " is a Prime number");
}
else

{
System.out.println(num + " is not a Prime number");
}

}
}