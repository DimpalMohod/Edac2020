class P7{
public static void main(String args[]){

for(int i=1;i<=10;i++)
{
	int num=8;
	int sum;
System.out.println(num+"*"+i+"="+num*i); 
}

}
}
