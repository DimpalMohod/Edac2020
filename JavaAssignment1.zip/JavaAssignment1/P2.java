/*class P2{
public static void main(String args[]){

int roll_no=100;
System.out.println("roll no = " + roll_no);

}
}
*/

class P2
{
	static int roll_no1=100;
	public static void main(String args[])
	{

		int roll_no2=11;
		System.out.println(P2.roll_no1);//100
		System.out.println(roll_no2);//11
	}
}