//Sort a ten element array in descending order.
import java.util.Scanner;
class P7{
public static void main(String args[]){
System.out.println("Enter no. of array elements to be sort ");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();      
int a[]=new int[n];   
int temp;
System.out.println("Enter elements to be sorted: ");
for(int i=0;i<a.length;i++)
{
	
	a[i]=sc.nextInt();
}
for(int i=0;i<a.length;i++)
{
	for(int j=i+1;j<a.length;j++)
	{
		if(a[i]<a[j])
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;		
		}
	}
}
System.out.println("The Sorted array:");
for(int i=0;i<a.length;i++)
{
	
	System.out.println(a[i]);
}

}
}
