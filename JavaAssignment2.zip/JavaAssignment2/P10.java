//10.	Write the program to find the sum of even elements and sum of odd elements present in the array of integer type.
import java.util.Scanner;
class P10{
public static void main(String args[]){
System.out.println("Enter array elements");
Scanner sc=new Scanner(System.in);
int sumE=0,sumO=0;
int n=sc.nextInt();
int a[]=new int[n];
System.out.println("Enter array elements");
for(int i=0;i<a.length;i++)
{
	a[i]=sc.nextInt();
}
for(int i=0;i<a.length;i++)
{
	//int a[]=new int[i];
	if(a[i]%2==0)
	{
		sumE=sumE+a[i];
	}
	//System.out.println("Sum of even elements in an array: "+sumE);
	else
	{
		sumO=sumO+a[i];
	}
	//System.out.println("Sum of odd elements in an array: "+sumO);
}
System.out.println("Sum of even elements in an array: "+sumE);
System.out.println("Sum of odd elements in an array: "+sumO);

}
}