//1Write a program to print table of any entered number using loop.
import java.util.Scanner;
class P1{
public static void main(String args[]){

System.out.println("Enter number");

Scanner sc=new Scanner(System.in);
int n=sc.nextInt();

for(int i=1;i<=10;i++)
{
System.out.println(n+" * "+ i +" = "+ n*i);
}
}
}


