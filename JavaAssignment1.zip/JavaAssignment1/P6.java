import java.util.Scanner;
class P6{
public static void main(String args[]){

System.out.println("Enter radius: ");
Scanner sc = new Scanner(System.in);

int r = sc.nextInt();
float pi =3.14f;

double area = pi * r * r;
double cir = 2 * pi * r;

System.out.println("Area : "+ area);
System.out.println("Circumference : "+cir);

}
}