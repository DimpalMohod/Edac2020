//Program to show sum and average of 10 element array. Accept array elements from user. 
import java.util.Scanner;
class P6{
public static void main(String args[]){
System.out.println("Enter no of elements in an array you want:");

Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int a[]=new int[n];
int total=0;
	for(int i=0;i<a.length;i++)
	{
		System.out.print("Enter Element");
		a[i]=sc.nextInt();
	}
	for(int i=0;i<a.length;i++)
	{
		total=total+a[i];
	}
	System.out.println(total);
	int avg = total / a.length;
        
        System.out.println(avg);

}
}

