class P3{
public static void main(String args[]){
int a=50,b=3,c=0;

c=a/b;

System.out.println(c);

}
}
