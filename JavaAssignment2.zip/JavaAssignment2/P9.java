//9.Write a program to search an element in the array.
import java.util.Scanner;
class P9{
public static void main(String args[]){
System.out.println("enter no of elemensts you want");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int a[]=new int[n];
System.out.println("Enter array elements");
for(int i=0;i<a.length;i++)
{
	a[i]=sc.nextInt();
}

int flag=1;
System.out.println("Search any element");
int x=sc.nextInt();
for(int i=0;i<a.length;i++)
{
	if(a[i]==x)
	{
		flag=0;
		break;
	}
	else
	{
		flag=1;
	}
}
if(flag==0)
{
System.out.println("Element found");
}
else
{
System.out.println("Element not found");
}

}
}