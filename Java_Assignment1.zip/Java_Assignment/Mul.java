class Mul{
public static void main(String args[]){

int a=10,b=11,c;
c=a*b;

System.out.println("Multiplication is:" + c );

}
}