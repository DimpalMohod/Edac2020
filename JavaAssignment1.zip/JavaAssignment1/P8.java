import java.util.Scanner;
class P8{
public static void main(String args[]){
System.out.println("Enter Principal, Rate of interest, Time");

Scanner sc=new Scanner(System.in);

int prin=sc.nextInt();
int rot=sc.nextInt();
int n=sc.nextInt();

float SI = (prin*rot*n)/100;

System.out.println(SI);

}
}
