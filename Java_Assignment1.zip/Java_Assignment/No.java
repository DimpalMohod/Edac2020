class No{
public static void main(String args[]){
int a=20;
int b=30;
int temp;

System.out.println("Before swapping value of a and b is :" + a+ " and " + b);

temp=a;
a=b;
b=temp;

System.out.println("After swapping value of a and b is :" + a + " and " + b);

}
}