class P4{
public static void main(String aargs[])
{

byte a=2;
byte b=4;
byte result=(byte) (a+b);

System.out.println(result);

}
}