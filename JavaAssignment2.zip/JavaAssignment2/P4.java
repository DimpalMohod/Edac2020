//12+22+32+42+.........+n2
import java.util.Scanner;
class P4{
public static void main(String args[]){

System.out.println("Enter number");
Scanner sc=new Scanner(System.in);

int n=sc.nextInt();

int result= (n * (n + 1) * (2 * n + 1)) /6;

System.out.println(result);

}
}
