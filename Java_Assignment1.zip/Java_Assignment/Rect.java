class Rect{
public static void main(String[] args){

float wd=5.6f,ht=8.5f,area,perimetre;
area=wd*ht;
perimetre=2*(wd+ht);

System.out.println("Area is:" +area );
System.out.println("Perimetre is :" +perimetre);
//Area is:47.6
//Perimetre is :28.2

}
}
