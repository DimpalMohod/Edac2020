import java.util.Scanner;
class P11{
public static void main(String args[]){

System.out.println("Enter nos to be swap");
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();

System.out.println("Nos before swapping : "+a +" "+ b);
a=a+b;
b=a-b;
a=a-b;

System.out.println("Nos after swapping : "+a +" "+ b );

}
}