/*class P3{
public static void main(String args[]){

int x=2;
int y=x*x+3*x-7;

System.out.println("The value of y is :" + y);

}
}
*/

/*class P3{
public static void main(String args[]){

int x=20;
int y = x++ + ++x;

System.out.println("The value of x & y is :" + x +" "+ y);

}
}
*/

/*
class P3{
public static void main(String args[]){

int x=4;
int y=2;
int z = x++ - --y - --x + x++;

System.out.println("The value of x & y is :" + x +" "+ y+" "+ z);

}
}

*/

class P3{
public static void main(String args[]){

boolean x=false;
boolean y=false;

boolean z = x && y || !(x||y) ;
System.out.println("The value of z:" + z);

}
}




















