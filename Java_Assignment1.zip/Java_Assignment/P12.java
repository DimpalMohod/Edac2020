import java.util.Scanner;
class P12{
public static void main(String args[]){

Scanner sc=new Scanner(System.in);
System.out.println("Enter any three numbers");
int a=sc.nextInt();
int b=sc.nextInt();
int c=sc.nextInt();
int avg;
avg=(a+b+c)/3;

System.out.println("Average of the numbers is: "+ avg);

}
}
//Enter any three numbers
1
2
3
Average of the numbers is: 2
