import java.util.Scanner;
class DtoB{
public static void main(String args[]){

Scanner sc=new Scanner(System.in);
System.out.println("Enter DEcimal number");

n=sc.nextInt();

while(n%2!=0)

