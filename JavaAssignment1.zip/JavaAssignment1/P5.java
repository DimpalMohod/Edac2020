/*import java.util.Scanner;
class P5{
public static void main(String args[])
{

System.out.println("Enter your name");

Scanner sc = new Scanner(System.in);
String name=sc.nextLine();

System.out.println("Welcome " + name);

}
}
*/

class P5{
public static void main(String args[]){
System.out.println("Welcome "+ args[0]);
}
}
