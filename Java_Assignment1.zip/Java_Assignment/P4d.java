class P4d{
public static void main(String args[]){
int a=5,b=15,c=3,d=2,e=8,f=3,op;
op=a+b/c*d-e%f;
System.out.println(op);
}
}
