class P13{
public static void main(String args[]){

for(int i=1;i<=6;i++)
{
 for(int j=6;j<=1;j--)
 {
  System.out.print("*");
 }
}
for(int s=5;s<=1;s--)
{
 System.out.print(" ");
}
System.out.println();
}
}