import java.util.Scanner;
class P7{
public static void main(String args[])
{

System.out.println("Enter 5 subject marks");
Scanner sc=new Scanner(System.in);
int S1=sc.nextInt();
int S2=sc.nextInt();
int S3=sc.nextInt();
int S4=sc.nextInt();
int S5=sc.nextInt();

int marks_obtnd=S1+S2+S3+S4+S5;
int total_marks=750;

float per= (marks_obtnd * 100) / 750;
System.out.println("Percentage : " + per+"%");

}
}