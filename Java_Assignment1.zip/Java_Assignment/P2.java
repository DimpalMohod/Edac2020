class P2{
public static void main(String args[]){
int a=74, b=36, c;
c= a+b;
System.out.println(c);
}
}