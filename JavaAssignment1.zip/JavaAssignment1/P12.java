import java.util.Scanner;
class P12{

public static void main(String args[]){

double Basic_Salary, DA, HRA, Gross_Salary;
Scanner sc=new Scanner(System.in);

System.out.println("Enter basic salary ");
Basic_Salary=sc.nextDouble();
if(Basic_Salary<10000)
{
	DA=(Basic_Salary*90)/100;
	HRA=(Basic_Salary*90)/100;
	Gross_Salary=Basic_Salary + DA +HRA;
}
else
{
DA=(Basic_Salary*98)/100;
HRA=2000;
Gross_Salary=Basic_Salary+DA+HRA;
}
System.out.println("Gross-Salary :" +Gross_Salary);


}
}