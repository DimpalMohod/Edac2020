class P11{
public static void main(String args[]){

double radius=7.5, area;
float pi=3.14f;
area = pi*radius*radius;

System.out.println("Area is "+ area);//Area is 176.62500590085983

}
}