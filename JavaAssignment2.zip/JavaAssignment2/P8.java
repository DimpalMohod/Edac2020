//REVERSE ARRAY
import java.util.Scanner;
class P8{
public static void main(String args[]){

System.out.println("Enter no of elements you want");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();

int a[]=new int[n];
System.out.println("Enter elements in an array:");
for(int i=0;i<a.length;i++)
{
	a[i]=sc.nextInt();
}
System.out.println("Reversed array : ");
for(int i=a.length-1;i>=0;i--)
{
	System.out.println(a[i]);
}

}
}