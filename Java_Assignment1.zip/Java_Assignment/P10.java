class P10{
public static void main(String args[]){

double a=4.0d,c=1.0d,result;
int b=1,d=3,f=5,i=11,e=7,h=9;

result= a * (b-(c/d)+(c/f)-(c/e)+(c/h)-(c/i));

System.out.println(result);

}
}