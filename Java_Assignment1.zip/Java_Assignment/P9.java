class P9{
public static void main(String args[]){

float a=25.5f,b=3.5f,c=40.5f,d=4.5f;
double result;
result=(double)((a * b - b * b) / (c - d));

System.out.println(result);

}
}